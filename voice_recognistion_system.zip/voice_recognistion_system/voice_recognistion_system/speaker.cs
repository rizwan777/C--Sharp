﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Recognition;
using System.Speech.Synthesis;
using System.Diagnostics;

namespace voice_recognistion_system
{
    public partial class speaker : Form
    {
        public speaker()
        {
            InitializeComponent();
        }
        SpeechSynthesizer ssther = new SpeechSynthesizer();
        PromptBuilder builder = new PromptBuilder();
        SpeechRecognitionEngine engine = new SpeechRecognitionEngine();
        private void speaker_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            builder.ClearContent();
            builder.AppendText(textBox1.Text);
            ssther.Speak(builder);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button2.Enabled = false;
            button2.Enabled = true;
            Choices list = new Choices();
            list.Add(new string[] { "hello","exit", "open internet", "stop","Tell me something about china", "Tell me something about rizhao", "What are you doing now", "how","are","you","today","i","am","whats","your","name","doing","what","time" ,"is", "now","rizwan","nikul","amy","hellmen", "what time is it now in china" });
            Grammar gr = new Grammar(new GrammarBuilder(list));
            try
            {
                engine.RequestRecognizerUpdate();
                engine.LoadGrammar(gr);
                engine.SpeechRecognized += srecognize_speeachRechonization;
                engine.SetInputToDefaultAudioDevice();
                engine.RecognizeAsync(RecognizeMode.Multiple);

            }
            catch (Exception se)
            {
                MessageBox.Show(se.StackTrace);
            }

        }
        private void srecognize_speeachRechonization(object s, SpeechRecognizedEventArgs e)
        {
            //            MessageBox.Show("Speeach Recognized " + e.Result.Text.ToString());

            if (e.Result.Text == "exit")
            {
                Application.Exit();
            }
            else if (e.Result.Text == "what time is it now in china")
            {
                builder.ClearContent();
                textBox1.Text = "Time in china is, " + System.DateTime.Now.ToString();

                builder.AppendText(textBox1.Text);
                ssther.Speak(builder);

            }
            else if (e.Result.Text == "open internet")
            {
                Process.Start("chrome","http://www.baidu.com");
                
            }

            else if (e.Result.Text == "Tell me something about china")
            {
                builder.ClearContent();
                textBox1.Text = "China, officially the People's Republic of China (PRC), is a unitary sovereign state in East Asia and the world's most populous country, with a population of around 1.404 billion.[13] Covering approximately 9,600,000 square kilometers (3,700,000 sq mi), it is the third- or fourth-largest country by total area,[k][21] depending on the source consulted. China also has the most neighbor countries in the world. Governed by the Communist Party of China, it exercises jurisdiction over 22 provinces, five autonomous regions, four direct-controlled municipalities (Beijing, Tianjin, Shanghai, and Chongqing), and the special administrative regions of Hong Kong and Macau.";

                builder.AppendText(textBox1.Text);
                ssther.Speak(builder);
            }
            else if (e.Result.Text == "Tell me something about rizhao")
            {
                builder.ClearContent();
                textBox1.Text = "Rizhao is a small place on the coast of Shandong province in China. Hidden within its city and its adminstration area is a vast untapped area of jeweled sights. Those in the city can easily tell any passing foreigner the most popular places to visit. Over the nex few weeks and months that I am here I plan to visit them and many more.";
                builder.AppendText(textBox1.Text);
                ssther.Speak(builder);
            }
            else if (e.Result.Text == "hello")
            {
                builder.ClearContent();
                textBox1.Text = "hii Rizwan, how are you?";
                builder.AppendText(textBox1.Text);
                ssther.Speak(builder);
            }
            else if (e.Result.Text == "stop")
            {
                builder.ClearContent();
                textBox1.Text = "";
                builder.AppendText(textBox1.Text);
                ssther.Speak(builder);
            }
            else if (e.Result.Text == "What are you doing now")
            {
                builder.ClearContent();
                textBox1.Text = "Nothing now, i am just waiting for instruction by rizwan...!!";
                builder.AppendText(textBox1.Text);
                ssther.Speak(builder);
            }
            else
            {
                textBox1.Text = textBox1.Text + " " + e.Result.Text.ToString();
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            engine.RecognizeAsyncStop();
        }
    }
}
